#include "OLED_UI_MenuData.h"
#include "stdlib.h"
#define SPEED 3.0f
#define ANIMATION  UNLINEAR
extern MenuPage MainMenuPage;
bool if_EnableWaterBump;
bool if_Res;

int16_t WaterBumpPwr = 200;
MenuWindow windowTest1 = {
    .General_FrameStyle = WINDOW_FRAME_ROUNDRECTANGLE,
    .General_Height = 30,
    .General_Width = 80,
    .General_StayTime = 30000,

    .Title_text = "ˮ�����ٵ���",
    .Title_FontSize = OLED_FONT_12,
    .Title_FontSideDistance = 3,
    .Title_FontTopDistance = 3,

    .Prob_FontSize = OLED_FONT_12,
    .Prob_Data_Int_16_t = &WaterBumpPwr,
    .Prob_FloatPointLength = 2,
    .Prob_DataStep = 5,
    .Prob_BottomDistance = 3,
    .Prob_SideDistance = 3,
    .Prob_MaxData = 999,
    .Prob_MinData = 200,
    .Prob_LineHeight = 10,
};

void OLED_WindowTest1(void){
    OLED_UI_CreateWindow(&windowTest1);
}
static inline float rand_float01(void)
{
    /* ��ǿ��ת��Ϊ float���ٳ������� int / int ���� 0 */
    return (float)rand() / (float)RAND_MAX;
}

double map_linear(double x,
                  double in_min, double in_max,
                  double out_min, double out_max)
{

    return (x - in_min) * (out_max - out_min) /
           (in_max - in_min) + out_min;
}

void OLED_MAIN_AUX(void){

	if(if_EnableWaterBump){
  PWM_SetDutyCycle(WaterBumpPwr);
	}else{
		PWM_SetDutyCycle(0);
	}
	if(if_Res){
			GPIO_SetBits(GPIOB, GPIO_Pin_0);
	    GPIO_ResetBits(GPIOB, GPIO_Pin_1);
	}else{
		  GPIO_ResetBits(GPIOB, GPIO_Pin_0);
	  GPIO_SetBits(GPIOB, GPIO_Pin_1);
	}


	
	OLED_Printf(87,16,OLED_FONT_12,"����:\n%.2f\nʹ��:%d",WaterBumpPwr,if_EnableWaterBump);

}
MenuPage MainMenuPage = {

    // ͨ������
    .General_MenuArea = {1, 1, 82, 62},
    .General_MenuFrameStyle = MENU_FRAME_ROUNDRECTANGLE,
    .General_InitMenuID = 0,
    .General_InitSlot = 0,
    .General_MenuType = MENU_TYPE_LIST,
    .General_CursorStyle = CURSOR_REVERSE_ROUNDRECTANGLE,
    .General_FontSize = OLED_FONT_12,
    .General_ParentMenuPage = NULL,
    .General_LineSpace = 3,
    .General_MoveStyle = ANIMATION,
    .General_MovingSpeed = SPEED,
    .General_ShowAuxiliaryFunction = OLED_MAIN_AUX,
    // ��������
    .General_StartPoint = {3,3},
    .List_IfDrawLinePerfix = true,

    // �˵�������
    .General_MenuItems = (MenuItem[]){
			{.General_item_text = "ʹ��ˮ��", .General_callback = NULL, .General_SubMenuPage = NULL, .List_BoolRadioBox = &if_EnableWaterBump},
        {.General_item_text = "���ٵ���", .General_callback = OLED_WindowTest1, .General_SubMenuPage = NULL, .List_BoolRadioBox = NULL},
        
  

        {.General_item_text = "��ת", .General_callback = NULL, .General_SubMenuPage = NULL, .List_BoolRadioBox = &if_Res},

        
        {.General_item_text = NULL}, // ���һ���ʾ�ָ���
    },

};


